
public enum Lop {
	EconomyPassenger,
	VIP,
	FlightStaff
}
