
public class Airport {

	private String name;
	private Lop type;

	public Airport(String name ,Lop type  ) {
		this.name= name ;
		this.type= type;
	}
	public String toString() {
	    return String.format("%s is %s will go to this line", name, type);
	  }
	public Lop getLop() {
	    return this.type;
	  }

}
