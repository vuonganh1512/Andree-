public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Airport v1 = new Airport ("Andree", Lop.VIP);
		Airport v2 = new Airport ("Jane", Lop.EconomyPassenger );
		
		AirQ airq= new AirQ();
		
		airq.goThrough(v1);
		airq.goThrough(v2);
		System.out.println(airq.getNextPerson());
        
	      System.out.println(airq.getNextPerson());
	}

}
