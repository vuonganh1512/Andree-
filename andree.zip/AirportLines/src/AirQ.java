import java.util.LinkedList;
import java.util.Queue;

public class AirQ {
	private Queue<Airport> economy = new LinkedList<Airport>();
	private Queue<Airport> vip = new LinkedList<Airport>();
	private Queue<Airport> staff = new LinkedList<Airport>();

	public void goThrough(Airport ap) {
		if (ap.getLop() == Lop.VIP) {
			vip.add(ap);
		} else if (ap.getLop() == Lop.FlightStaff) {
			staff.add(ap);
		} else {
			economy.add(ap);
		}
	}

	public Airport getNextPerson() {
		if (!vip.isEmpty()) {
			return vip.poll();
		} else if (!staff.isEmpty()) {
			return staff.poll();
		} else {
			return economy.poll();
		}
	}

}
